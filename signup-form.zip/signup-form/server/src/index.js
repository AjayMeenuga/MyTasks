const express = require("express")
const path = require("path")
const app = express()
// const hbs = require("hbs")
const User = require("./mongo.js")
const port = process.env.PORT || 3000
app.use(express.json())

app.use(express.urlencoded({ extended: false }))

const tempelatePath = path.join(__dirname, '../tempelates')
const publicPath = path.join(__dirname, '../public')
console.log(publicPath);

app.set('view engine', 'hbs')
app.set('views', tempelatePath)
app.use(express.static(publicPath))


// hbs.registerPartials(partialPath)



app.get('/', (req, res) => {
    return res.render('signup')
})

app.get("/success", (req, res) => {
    res.status(201).render("signup_success", {
        naming: req.body.name
    })

})



// app.get('/home', (req, res) => {
//     res.render('home')
// })
app.post('/signup', async (req, res) => {
    const { name, email, password, dob } = req.body;
    try {

        const newUser = await User.create({ name, email, password, dob });

        // Save the user to the database
        await newUser.save();

        return res.status(201).render("signup_success", {
            naming: req.body.name
        });

    } catch (error) {
        console.error(error);
        return res.status(201).render("signup_success", {
            naming: req.body.name,
            email: req.body.email
        });
        res.status(500).send("Internal Server Error");
    }
});






app.listen(port, () => {
    console.log('port connected');
})