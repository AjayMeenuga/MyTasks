
const mongoose = require("mongoose")
mongoose.connect("mongodb+srv://admin:admin@test1.coqyjll.mongodb.net/registration?retryWrites=true&w=majority")
    .then(() => {
        console.log('mongoose connected');
    })
    .catch((e) => {
        console.log('failed');
    })

const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    },
    dob: {
        type: String,
        required: true
    }
})
const users = new mongoose.model('users', userSchema)

exports.default = users;